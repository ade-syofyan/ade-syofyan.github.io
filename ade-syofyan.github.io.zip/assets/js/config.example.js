// d:/MasterWeb/ade-syofyan.github.io/assets/js/config.example.js
// Salin file ini dan ganti namanya menjadi 'config.js'.
// Kemudian, isi nilai variabel di bawah ini dengan kunci API Anda.

const API_KEY = "MASUKKAN_KUNCI_API_GEMINI_ANDA_DI_SINI";
const FORMSPREE_ID = "MASUKKAN_ID_FORMSPREE_ANDA_DI_SINI";
