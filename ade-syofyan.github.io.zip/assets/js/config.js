// d:/MasterWeb/ade-syofyan.github.io/assets/js/config.js
// PENTING: JANGAN UNGGAH FILE INI KE GITHUB.
// Tambahkan 'assets/js/config.js' ke file .gitignore Anda.

const API_KEY = "AIzaSyAYoqmGxZT9FwG2obC3-xpxSN6orVxi0Wk";
const FORMSPREE_ID = "xdkwnqyw";